package com.cts.ja;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ct= new AnnotationConfigApplicationContext(conif.class);
        Product prod=ct.getBean(Product.class);
        prod.setProDesc("tv");
        prod.setProId(21);
        prod.setProname("sudheer");
        System.out.println(prod);
	}

}
