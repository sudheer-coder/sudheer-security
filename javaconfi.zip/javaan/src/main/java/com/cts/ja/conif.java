package com.cts.ja;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class conif { 
	@Bean
	public Product product() 
	{ 
		return new Product();
	}

}
