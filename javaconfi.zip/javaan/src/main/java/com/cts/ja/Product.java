package com.cts.ja;

public class Product {
	private String proname;
	private int proId;
	private String proDesc;
	public Product() 
	{ 
		
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public int getProId() {
		return proId;
	}
	public void setProId(int proId) {
		this.proId = proId;
	}
	public String getProDesc() {
		return proDesc;
	}
	public void setProDesc(String proDesc) {
		this.proDesc = proDesc;
	}
	@Override
	public String toString() {
		return "Product [proname=" + proname + ", proId=" + proId + ", proDesc=" + proDesc + "]";
	}
	
	

}
